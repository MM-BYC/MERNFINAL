
// Backend [M,E,N]
// npm init -y
// npm i express mongoose dotenv nodemon cookie-parser 
// -> Create Server
// -> Establish  Database
// -> Make Routes 
// -> Make Controllers
// ===================================
// Frontend [R]

// --> Create a route for "proxy" to connect to so it can talk to the frontend [proxy goes in frontend package_json]
// Create Components that would give CRUD func() for each model

// Establish state needed before the application
// Create CRUD Routes 


// USERS & AUTH
// npm i bcrypt jsonwebtoken
// ---models
// ---controllers


